  // srv array
  let received_topic_list=[]
  let received_node_list=[]



  /////////////////////////////// Get Publisher list
  function getNodes(){

    var NodeClient = new ROSLIB.Service({
      ros : ros,
      name : '/rosapi/nodes',
      serviceType : 'rosapi/nodes'
    });

    var request = new ROSLIB.ServiceRequest();
 
    NodeClient.callService(request, function(result) {
    console.log("Getting nodes...");

    console.log(result.nodes)
    // reulst shape 
    // string[] publishers
    // http://docs.ros.org/en/melodic/api/rosapi/html/srv/Publishers.html

    received_node_list.push(result)
    
  });
  
    
    return received_node_list
};

let node_list=getNodes();

//set the topic list  
const setPubList=(node_list)=>{


    for (let i=0;i<node_list.nodes.length;i++){
      let node=node_list.nodes[i]
  
      document.getElementById("node_list_length").innerHTML=`${node_list.nodes.length} Nodes`
      let list = document.getElementById("node_list");
      let listCoponent = document.createElement('h1');
      listCoponent.innerHTML=`Node : ${node}`
      list.appendChild(listCoponent)
      

   }
  

  }



  
  ////////////////////////// Get Topic list
  function getTopics(){
    var topicsClient = new ROSLIB.Service({
    ros : ros,
    name : '/rosapi/topics',
    serviceType : 'rosapi/Topics'
    });

    var request = new ROSLIB.ServiceRequest();

    topicsClient.callService(request, function(result) {
    console.log("Getting topics...",received_topic_list);

    // reulst shape 
    // string[] topics / string[] types
    // http://docs.ros.org/en/melodic/api/rosapi/html/srv/Topics.html
    received_topic_list.push(result)

    });

    return received_topic_list
};
  // get srv msg
  let topic_list=getTopics();

  //set the topic list
  const setTopicList=(topiclist)=>{


  for (let i=0;i<topiclist.topics.length;i++){
    let topic=topiclist.topics[i]
    let type=topiclist.types[i]

    document.getElementById("topic_list_length").innerHTML=`${topiclist.topics.length} topics`
    let list = document.getElementById("topic_list");
    let listCoponent = document.createElement('h1');
    listCoponent.innerHTML=`Topic : ${topic}  ,   Type : ${type}`
    list.appendChild(listCoponent)
    
  }

}


function LoadTopic() {
  setTimeout(function () {
    setTopicList(topic_list[0])
    setPubList(received_node_list[0])
  }, 2000);
}

$("#btn_topic").on("click", function () {
  LoadTopic()
});

